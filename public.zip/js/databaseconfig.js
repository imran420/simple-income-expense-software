// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyA9bjBcC0No7-0vzMv8VB1nviv82qAdd0g",
    authDomain: "wordaccounting.firebaseapp.com",
    databaseURL: "https://wordaccounting.firebaseio.com",
    projectId: "wordaccounting",
    storageBucket: "wordaccounting.appspot.com",
    messagingSenderId: "321534353708",
    appId: "1:321534353708:web:d1a696d826dfdfa83ecc89",
    measurementId: "G-CG1DY0K3WR"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();